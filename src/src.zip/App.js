import Main_Page from "./Main page/MainPage";


function App() {
  return (
    <div className="App">
        <Main_Page/>
    </div>
  );
}

export default App;
